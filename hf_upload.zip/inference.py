import requests

BASE_URL = "http://localhost:8000"


def run_inference(task_name: str = "easy"):
    res = requests.post(f"{BASE_URL}/reset")
    observation = res.json()
    print("Initial state:", observation)

    inbox = observation.get("inbox", [])
    actions = []

    for i, email in enumerate(inbox):
        subject = email.get("subject", "")
        if "Lottery" in subject or "Win" in subject or "prize" in subject.lower():
            action = {"action_type": "delete", "email_index": i, "response": ""}
        elif "Meeting" in subject or "Update" in subject:
            action = {"action_type": "reply", "email_index": i, "response": "Thank you for your email."}
        else:
            action = {"action_type": "reply", "email_index": i, "response": "Noted."}

        actions.append(action)

        step_res = requests.post(f"{BASE_URL}/step", json=action)
        print(f"Step result for '{subject}':", step_res.json())

    grade_res = requests.post(
    f"{BASE_URL}/grader",
    params={"task_name": task_name},
    json={"actions": actions}   # <-- wrap in {"actions": ...}
     )
    print("Grade result:", grade_res.json())
    return grade_res.json()


if __name__ == "__main__":
    for task in ["easy", "medium", "hard"]:
        print(f"\n=== Running task: {task} ===")
        run_inference(task)