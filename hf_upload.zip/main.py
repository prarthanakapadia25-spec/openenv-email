from fastapi import FastAPI
from pydantic import BaseModel
from typing import List

app = FastAPI()

class Email(BaseModel):
    subject: str
    body: str

class Action(BaseModel):
    action_type: str
    email_index: int = 0
    response: str = ""

class GradeRequest(BaseModel):
    actions: list

inbox: List[Email] = []

TASKS = [
    {"name": "easy",   "goal": "Delete spam email"},
    {"name": "medium", "goal": "Reply correctly to meeting email"},
    {"name": "hard",   "goal": "Handle all emails correctly"},
]

def reset_inbox():
    global inbox
    inbox = [
        Email(subject="Meeting Tomorrow", body="Please confirm your availability."),
        Email(subject="Win Lottery!!!",   body="Click this link to claim prize"),
        Email(subject="Project Update",   body="Send latest report."),
    ]
    return inbox

def grade(task_name: str, actions: list) -> float:
    if not actions:
        return 0.0
    if task_name == "easy":
        return 1.0 if actions[0].get("action_type") == "delete" else 0.0
    if task_name == "medium":
        return 1.0 if actions[0].get("action_type") == "reply" else 0.5
    if task_name == "hard":
        correct = sum(1 for a in actions if a.get("action_type") in ["reply", "delete"])
        return correct / len(actions)
    return 0.0

@app.get("/")
def home():
    return {"message": "Email Agent Environment is running", "docs": "/docs"}

@app.post("/reset")
def reset():
    emails = reset_inbox()
    return {"inbox": [e.model_dump() for e in emails]}

@app.post("/step")
def step(action: Action):
    global inbox
    if not inbox:
        reset_inbox()
    reward = 0.0
    if action.email_index < len(inbox):
        email = inbox[action.email_index]
        if action.action_type == "delete" and "Lottery" in email.subject:
            reward = 1.0
        elif action.action_type == "reply" and "Meeting" in email.subject:
            reward = 0.8
        else:
            reward = -0.2
    return {"score": reward}

@app.get("/state")
def state():
    if not inbox:
        reset_inbox()
    return [e.model_dump() for e in inbox]

@app.get("/tasks")
def get_tasks():
    return TASKS

@app.post("/grader")
def run_grader(task_name: str, body: GradeRequest):
    return {"score": grade(task_name, body.actions)}

@app.get("/baseline")
def baseline():
    actions = [{"action_type": "delete"}, {"action_type": "reply"}]
    return {
        "easy":   grade("easy",   actions),
        "medium": grade("medium", actions),
        "hard":   grade("hard",   actions),
    }