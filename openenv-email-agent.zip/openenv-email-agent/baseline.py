import requests

BASE_URL = "http://localhost:8000"

def run():
    requests.get(f"{BASE_URL}/reset")

    action = {
        "action_type": "delete",
        "email_index": 1
    }

    res = requests.post(f"{BASE_URL}/step", json=action)
    print(res.json())

if __name__ == "__main__":
    run()