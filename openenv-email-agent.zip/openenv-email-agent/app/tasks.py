TASKS = [
    {
        "name": "easy",
        "goal": "Delete spam email"
    },
    {
        "name": "medium",
        "goal": "Reply correctly to meeting email"
    },
    {
        "name": "hard",
        "goal": "Handle all emails correctly"
    }
]