from app.models import Observation, Action, Reward, Email
import random

class EmailEnv:
    def __init__(self):
        self.state_data = []
        self.done = False

    def reset(self):
        self.state_data = [
            Email(subject="Meeting Tomorrow", body="Please confirm your availability."),
            Email(subject="Win Lottery!!!", body="Click this link to claim prize"),
            Email(subject="Project Update", body="Send latest report.")
        ]
        self.done = False
        return Observation(inbox=self.state_data)

    def step(self, action):
        reward = 0.0

        email = self.state_data[action.email_index]

        # Correct usage (dot notation)
        if action.action_type == "delete" and "Lottery" in email.subject:
            reward += 1.0
        elif action.action_type == "reply" and "Meeting" in email.subject:
            reward += 0.8
        else:
            reward -= 0.2

        self.done = True

        return {"score": reward}

    def state(self):
        return self.state_data