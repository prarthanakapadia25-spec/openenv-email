from pydantic import BaseModel
from typing import List

class Email(BaseModel):
    subject: str
    body: str

class Observation(BaseModel):
    inbox: List[Email]

class Action(BaseModel):
    action_type: str  # classify / reply / delete
    email_index: int
    response: str = ""

class Reward(BaseModel):
    score: float