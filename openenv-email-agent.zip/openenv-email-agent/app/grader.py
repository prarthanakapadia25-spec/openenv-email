def grade(task_name, actions):
    if task_name == "easy":
        return 1.0 if actions[0]["action_type"] == "delete" else 0.0

    if task_name == "medium":
        return 1.0 if actions[0]["action_type"] == "reply" else 0.5

    if task_name == "hard":
        correct = sum(1 for a in actions if a["action_type"] in ["reply", "delete"])
        return correct / len(actions)