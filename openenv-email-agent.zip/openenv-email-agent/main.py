from fastapi import FastAPI
from app.env import EmailEnv
from app.models import Action
from app.grader import grade
from app.tasks import TASKS
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

# ✅ FIRST create app
app = FastAPI()
env = EmailEnv()

# ✅ THEN mount static
app.mount("/static", StaticFiles(directory="app/static"), name="static")

# ✅ ONLY ONE home route
@app.get("/")
def home():
    return FileResponse("app/static/index.html")

@app.get("/reset")
def reset():
    return env.reset()

@app.post("/step")
def step(action: Action):
    return env.step(action)

@app.get("/state")
def state():
    return env.state()

@app.get("/tasks")
def get_tasks():
    return TASKS

@app.post("/grader")
def run_grader(task_name: str, actions: list):
    score = grade(task_name, actions)
    return {"score": score}

@app.get("/baseline")
def baseline():
    actions = [
        {"action_type": "delete"},
        {"action_type": "reply"}
    ]

    return {
        "easy": grade("easy", actions),
        "medium": grade("medium", actions),
        "hard": grade("hard", actions)
    }